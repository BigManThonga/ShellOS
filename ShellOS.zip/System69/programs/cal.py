import calendar
import tkinter as tk

def display_calendar():
    year = int(year_entry.get())
    month = int(month_entry.get())
    
    cal_content = calendar.month(year, month)
    cal_label.config(text=cal_content)

def on_fullscreen_toggle(event=None):
    state = not root.attributes('-fullscreen')
    root.attributes('-fullscreen', state)
    root.update_idletasks()  # Update window contents when entering full-screen mode

def on_fullscreen_exit(event=None):
    root.attributes('-fullscreen', False)
    root.geometry('400x300')  # Set the window size when exiting full-screen mode
    root.update_idletasks()  # Update window contents when exiting full-screen mode

root = tk.Tk()
root.title("Graphical Calendar App")

# Entry fields for month and year
tk.Label(root, text="Year:").grid(row=0, column=0)
year_entry = tk.Entry(root)
year_entry.grid(row=0, column=1)

tk.Label(root, text="Month:").grid(row=1, column=0)
month_entry = tk.Entry(root)
month_entry.grid(row=1, column=1)

# Button to display the calendar
show_btn = tk.Button(root, text="Show Calendar", command=display_calendar)
show_btn.grid(row=2, columnspan=2)

# Label to display the calendar
cal_label = tk.Label(root, text="", font=("Courier", 12))
cal_label.grid(row=3, columnspan=2)

# Bind the F11 key to toggle full-screen mode
root.bind('<F11>', on_fullscreen_toggle)
root.bind('<Escape>', on_fullscreen_exit)

root.mainloop()