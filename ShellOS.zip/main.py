import tkinter as tk
import subprocess
import os

class OSApp:
    def __init__(self, root):
        self.root = root
        self.root.title("ShellOS")
        self.root.geometry("800x600")

        # Create a taskbar
        self.taskbar = tk.Frame(root, bg="gray", height=40)
        self.taskbar.pack(side="bottom", fill="x")

        # Create a Launcher button (aligned to the left)
        self.launcher_button = tk.Button(self.taskbar, text="Launcher", command=self.open_launcher)
        self.launcher_button.pack(side="left", padx=0)  # Adjusted the padx value

    def open_launcher(self):
        launcher_path = os.path.join("System69", "Launcher.py")  # Corrected path separator
        try:
            subprocess.run(["python", launcher_path])
        except FileNotFoundError:
            print(f"Error: {launcher_path} not found.")

if __name__ == "__main__":
    root = tk.Tk()
    app = OSApp(root)
    root.mainloop()
